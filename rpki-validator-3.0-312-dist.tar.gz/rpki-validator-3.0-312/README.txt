The RPKI Validator 3 project is documented in the wiki:
https://github.com/RIPE-NCC/rpki-validator-3/wiki
